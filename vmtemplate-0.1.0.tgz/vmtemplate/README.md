# vmtemplate

一个用于在 KubeVirt + KubeOVN 环境中声明式创建和管理虚拟机的 Helm Chart。

## 功能特性

- 基于容器镜像的 OS 模板，通过 CDI DataVolume 自动导入系统盘
- 可配置的 CPU、内存计算资源
- 基于 KubeOVN + Multus 的网络配置，支持静态 IP 分配
- 支持动态扩展额外数据盘

## 前置依赖

- Kubernetes 集群
- [KubeVirt](https://kubevirt.io/) (appVersion: 0.58.1+)
- [CDI (Containerized Data Importer)](https://github.com/kubevirt/containerized-data-importer)
- [Multus CNI](https://github.com/k8snetworkplumbingwg/multus-cni) + OVN
- 可用的存储后端（默认使用 Longhorn）

## 安装

```bash
helm install my-vm ./vmtemplate
```

自定义配置：

```bash
helm install my-vm ./vmtemplate -f custom-values.yaml
```

## 配置说明

| 参数                       | 说明                                            | 默认值                                                                       |
| -------------------------- | ----------------------------------------------- | ---------------------------------------------------------------------------- |
| `osTemplate`               | OS 镜像地址                                     | `registry.cn-hangzhou.aliyuncs.com/amanises/vm-centos7:2009-amd64-minimized` |
| `compute.cpu`              | CPU 核心数                                      | `4`                                                                          |
| `compute.memory`           | 内存大小                                        | `8Gi`                                                                        |
| `disk.system.storageClass` | 系统盘 StorageClass                             | `longhorn`                                                                   |
| `disk.system.size`         | 系统盘大小                                      | `100Gi`                                                                      |
| `disk.system.volumeMode`   | 系统盘卷模式                                    | `Filesystem`                                                                 |
| `disk.extends`             | 额外数据盘列表                                  | `[]`                                                                         |
| `network.switch`           | KubeOVN Subnet                                  | `default`                                                                    |
| `network.default.network`  | KubeOVN in Multus 网络模板资源（命名空间/名称） | `default/ovn`                                                                |
| `network.default.ipv4`     | 静态 IPv4 地址                                  | `192.168.200.100`                                                            |

### 扩展数据盘示例

```yaml
disk:
  extends:
    - storageClass: longhorn
      size: 200Gi
      volumeMode: Filesystem
    - storageClass: longhorn
      size: 300Gi
      volumeMode: Filesystem
```

## 生成的资源

- `VirtualMachine` — KubeVirt 虚拟机实例
- `DataVolume` (系统盘) — 从容器镜像导入的系统磁盘
- `DataVolume` (扩展盘) — 按 `disk.extends` 列表创建的空白数据盘
